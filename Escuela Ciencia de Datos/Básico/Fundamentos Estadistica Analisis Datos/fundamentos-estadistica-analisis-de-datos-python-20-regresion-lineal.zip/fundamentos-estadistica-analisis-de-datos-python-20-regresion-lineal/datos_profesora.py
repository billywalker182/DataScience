# Datos de la profesora

NOMBRE = 'Katherine Briceño Guerrero'

PASATIEMPOS = 'Biología y música electronica'

PROFESION = 'Ingeniera industrial'

MASCOTAS = 'Dos extraños gatos'

CORREO = 'kbricenoguerrero@gmail.com'