# fundamentos-estadistica-analisis-de-datos-python
Este es un curso de probabilidad y estadística de primer nivel universitario. Las lecturas están acompañadas de videos demostrativos del código.
